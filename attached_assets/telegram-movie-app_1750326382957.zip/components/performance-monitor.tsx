"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Activity } from "lucide-react"

export function PerformanceMonitor() {
  const [cacheHitRate, setCacheHitRate] = useState<number>(0)
  const [showStats, setShowStats] = useState(false)

  useEffect(() => {
    // Monitor cache performance
    const checkCachePerformance = () => {
      if (typeof window !== "undefined") {
        const cacheKeys = Object.keys(localStorage).filter((key) => key.startsWith("cinestream_"))
        const totalRequests = Number.parseInt(localStorage.getItem("total_requests") || "0")
        const cacheHits = Number.parseInt(localStorage.getItem("cache_hits") || "0")

        if (totalRequests > 0) {
          setCacheHitRate((cacheHits / totalRequests) * 100)
        }
      }
    }

    checkCachePerformance()
    const interval = setInterval(checkCachePerformance, 5000)

    return () => clearInterval(interval)
  }, [])

  if (process.env.NODE_ENV !== "development") return null

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Badge
        variant="outline"
        className="cursor-pointer bg-black/80 backdrop-blur-sm"
        onClick={() => setShowStats(!showStats)}
      >
        <Activity className="w-3 h-3 mr-1" />
        Cache: {cacheHitRate.toFixed(0)}%
      </Badge>
    </div>
  )
}
