"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { User, Loader2 } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

export function TelegramAuth() {
  const { user, isLoading, login } = useAuth()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleTelegramLogin = async () => {
    setLoading(true)
    setError(null)
    try {
      login()

      // Show Telegram haptic feedback
      if (typeof window !== "undefined" && window.Telegram?.WebApp?.HapticFeedback) {
        window.Telegram.WebApp.HapticFeedback.notificationOccurred("success")
      }
    } catch (error) {
      console.error("Login failed:", error)
      setError("Authentication failed. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    )
  }

  if (user) {
    return (
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <User className="w-5 h-5" />
            Welcome, {user.first_name}!
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 text-sm">
            You're signed in via Telegram
            {user.username && ` as @${user.username}`}
          </p>
        </CardContent>
      </Card>
    )
  }

  const telegramUser = typeof window !== "undefined" && window.Telegram?.WebApp?.initDataUnsafe?.user

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardHeader>
        <CardTitle className="text-white">Sign in with Telegram</CardTitle>
      </CardHeader>
      <CardContent>
        {telegramUser ? (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              {telegramUser.photo_url && (
                <img
                  src={telegramUser.photo_url || "/placeholder.svg"}
                  alt="Profile"
                  className="w-10 h-10 rounded-full"
                />
              )}
              <div>
                <p className="text-white font-medium">
                  {telegramUser.first_name} {telegramUser.last_name}
                </p>
                {telegramUser.username && <p className="text-gray-400 text-sm">@{telegramUser.username}</p>}
              </div>
            </div>
            {error && <p className="text-red-400 text-sm">{error}</p>}
            <Button onClick={handleTelegramLogin} disabled={loading} className="w-full bg-blue-600 hover:bg-blue-700">
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Continue as {telegramUser.first_name}
            </Button>
          </div>
        ) : (
          <p className="text-gray-400 text-sm">Please open this app in Telegram to sign in</p>
        )}
      </CardContent>
    </Card>
  )
}
