"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Filter, X } from "lucide-react"
import { MovieAPI } from "@/lib/api"

interface Genre {
  id: number
  name: string
}

interface GenreFilterProps {
  onGenreSelect: (genreId: number | null) => void
  selectedGenre: number | null
}

export function GenreFilter({ onGenreSelect, selectedGenre }: GenreFilterProps) {
  const [genres, setGenres] = useState<Genre[]>([])
  const [showFilter, setShowFilter] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchGenres = async () => {
      try {
        const response = await MovieAPI.fetchGenres()
        setGenres(response.genres)
      } catch (error) {
        console.error("Error fetching genres:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchGenres()
  }, [])

  const selectedGenreName = genres.find((g) => g.id === selectedGenre)?.name

  if (loading) return null

  return (
    <div className="relative">
      <Button variant="outline" size="sm" onClick={() => setShowFilter(!showFilter)} className="whitespace-nowrap">
        <Filter className="w-4 h-4 mr-2" />
        {selectedGenreName || "Genre"}
        {selectedGenre && (
          <X
            className="w-3 h-3 ml-2"
            onClick={(e) => {
              e.stopPropagation()
              onGenreSelect(null)
            }}
          />
        )}
      </Button>

      {showFilter && (
        <Card className="absolute top-full left-0 mt-2 w-64 bg-gray-900 border-gray-800 z-50">
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
              {genres.map((genre) => (
                <Badge
                  key={genre.id}
                  variant={selectedGenre === genre.id ? "default" : "outline"}
                  className="cursor-pointer text-xs p-2 justify-center"
                  onClick={() => {
                    onGenreSelect(genre.id)
                    setShowFilter(false)
                  }}
                >
                  {genre.name}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
