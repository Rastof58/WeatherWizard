"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Play, X, Loader2 } from "lucide-react"

interface Video {
  id: string
  key: string
  name: string
  site: string
  type: string
  official: boolean
}

interface MovieTrailerProps {
  movieId: number
  movieTitle: string
}

export function MovieTrailer({ movieId, movieTitle }: MovieTrailerProps) {
  const [videos, setVideos] = useState<Video[]>([])
  const [loading, setLoading] = useState(false)
  const [showTrailer, setShowTrailer] = useState(false)
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null)

  const fetchVideos = async () => {
    try {
      setLoading(true)
      const response = await fetch(
        `https://api.themoviedb.org/3/movie/${movieId}/videos?api_key=${process.env.NEXT_PUBLIC_TMDB_API_KEY}`,
      )
      const data = await response.json()

      // Filter for YouTube trailers and teasers
      const trailers =
        data.results?.filter(
          (video: Video) =>
            video.site === "YouTube" && (video.type === "Trailer" || video.type === "Teaser") && video.official,
        ) || []

      setVideos(trailers)
      if (trailers.length > 0) {
        setSelectedVideo(trailers[0])
      }
    } catch (error) {
      console.error("Error fetching videos:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchVideos()
  }, [movieId])

  if (loading) {
    return (
      <Card className="bg-gray-900 border-gray-800">
        <CardContent className="p-4 text-center">
          <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
          <p className="text-sm text-gray-400">Loading trailers...</p>
        </CardContent>
      </Card>
    )
  }

  if (videos.length === 0) return null

  if (showTrailer && selectedVideo) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col">
        <div className="flex items-center justify-between p-4 bg-black/95">
          <h3 className="text-lg font-semibold text-white">{selectedVideo.name}</h3>
          <Button variant="ghost" size="icon" onClick={() => setShowTrailer(false)} className="text-white">
            <X className="w-5 h-5" />
          </Button>
        </div>
        <div className="flex-1">
          <iframe
            src={`https://www.youtube.com/embed/${selectedVideo.key}?autoplay=1&rel=0`}
            className="w-full h-full"
            allowFullScreen
            allow="autoplay; encrypted-media"
            title={selectedVideo.name}
          />
        </div>
      </div>
    )
  }

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardContent className="p-4">
        <h3 className="font-semibold mb-3 text-white">Trailers & Videos</h3>
        <div className="space-y-3">
          {videos.slice(0, 3).map((video) => (
            <div
              key={video.id}
              className="flex items-center gap-3 p-3 bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-700 transition-colors"
              onClick={() => {
                setSelectedVideo(video)
                setShowTrailer(true)
              }}
            >
              <div className="relative">
                <img
                  src={`https://img.youtube.com/vi/${video.key}/mqdefault.jpg`}
                  alt={video.name}
                  className="w-16 h-12 object-cover rounded"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Play className="w-6 h-6 text-white" fill="white" />
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-white line-clamp-1">{video.name}</p>
                <p className="text-xs text-gray-400">{video.type}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
