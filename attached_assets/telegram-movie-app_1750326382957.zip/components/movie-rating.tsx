"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Loader2 } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

interface MovieRatingProps {
  movieId: number
  movieTitle: string
}

interface UserRating {
  userId: string
  movieId: number
  rating: number
  review?: string
  createdAt: string
}

// In-memory storage for demo - replace with database in production
const ratingsStorage = new Map<string, UserRating[]>()

export function MovieRating({ movieId, movieTitle }: MovieRatingProps) {
  const { user } = useAuth()
  const [userRating, setUserRating] = useState<number>(0)
  const [hoverRating, setHoverRating] = useState<number>(0)
  const [loading, setLoading] = useState(false)
  const [averageRating, setAverageRating] = useState<number>(0)
  const [totalRatings, setTotalRatings] = useState<number>(0)

  useEffect(() => {
    if (user?.id) {
      loadRatings()
    }
  }, [movieId, user?.id])

  const loadRatings = () => {
    const movieKey = `movie_${movieId}`
    const ratings = ratingsStorage.get(movieKey) || []

    // Calculate average rating
    if (ratings.length > 0) {
      const avg = ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
      setAverageRating(avg)
      setTotalRatings(ratings.length)
    }

    // Find user's rating
    const userRatingObj = ratings.find((r) => r.userId === user?.id)
    if (userRatingObj) {
      setUserRating(userRatingObj.rating)
    }
  }

  const submitRating = async (rating: number) => {
    if (!user?.id || loading) return

    setLoading(true)
    try {
      const movieKey = `movie_${movieId}`
      const ratings = ratingsStorage.get(movieKey) || []

      // Remove existing rating from this user
      const filteredRatings = ratings.filter((r) => r.userId !== user.id)

      // Add new rating
      const newRating: UserRating = {
        userId: user.id,
        movieId,
        rating,
        createdAt: new Date().toISOString(),
      }

      filteredRatings.push(newRating)
      ratingsStorage.set(movieKey, filteredRatings)

      setUserRating(rating)
      loadRatings()

      // Telegram haptic feedback
      if (typeof window !== "undefined" && window.Telegram?.WebApp?.HapticFeedback) {
        window.Telegram.WebApp.HapticFeedback.impactOccurred("light")
      }
    } catch (error) {
      console.error("Error submitting rating:", error)
    } finally {
      setLoading(false)
    }
  }

  if (!user) return null

  return (
    <Card className="bg-gray-900 border-gray-800">
      <CardContent className="p-4">
        <h3 className="font-semibold mb-3 text-white">Rate this movie</h3>

        {/* Community Rating */}
        {totalRatings > 0 && (
          <div className="mb-4 p-3 bg-gray-800 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <Star className="w-4 h-4 text-yellow-500" fill="currentColor" />
              <span className="text-white font-medium">{averageRating.toFixed(1)}</span>
              <span className="text-gray-400 text-sm">({totalRatings} ratings)</span>
            </div>
          </div>
        )}

        {/* User Rating */}
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-400">Your rating:</span>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                className="p-1 transition-colors"
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                onClick={() => submitRating(star)}
                disabled={loading}
              >
                <Star
                  className={`w-6 h-6 ${
                    star <= (hoverRating || userRating) ? "text-yellow-500 fill-current" : "text-gray-600"
                  }`}
                />
              </button>
            ))}
          </div>
          {loading && <Loader2 className="w-4 h-4 animate-spin text-gray-400" />}
        </div>

        {userRating > 0 && (
          <p className="text-xs text-gray-400 mt-2">
            You rated this movie {userRating} star{userRating !== 1 ? "s" : ""}
          </p>
        )}
      </CardContent>
    </Card>
  )
}
