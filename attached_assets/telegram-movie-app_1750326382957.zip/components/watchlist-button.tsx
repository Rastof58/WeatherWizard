"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Heart, Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"

interface WatchlistButtonProps {
  movieId: number
  className?: string
}

// Simple in-memory watchlist storage
const watchlistStorage = new Map<string, Set<number>>()

export function WatchlistButton({ movieId, className }: WatchlistButtonProps) {
  const { user } = useAuth()
  const [inWatchlist, setInWatchlist] = useState(false)
  const [loading, setLoading] = useState(false)
  const [checking, setChecking] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const checkWatchlistStatus = async () => {
      if (!user?.id) {
        setChecking(false)
        return
      }

      try {
        const userWatchlist = watchlistStorage.get(user.id) || new Set()
        setInWatchlist(userWatchlist.has(movieId))
      } catch (error) {
        console.error("Error checking watchlist:", error)
      } finally {
        setChecking(false)
      }
    }

    checkWatchlistStatus()
  }, [movieId, user?.id])

  const toggleWatchlist = async () => {
    if (!user) {
      router.push("/auth/signin")
      return
    }

    if (!user?.id || loading) return

    setLoading(true)
    try {
      if (!watchlistStorage.has(user.id)) {
        watchlistStorage.set(user.id, new Set())
      }

      const userWatchlist = watchlistStorage.get(user.id)!

      if (inWatchlist) {
        userWatchlist.delete(movieId)
      } else {
        userWatchlist.add(movieId)
      }

      setInWatchlist(!inWatchlist)

      // Show Telegram haptic feedback
      if (typeof window !== "undefined" && window.Telegram?.WebApp?.HapticFeedback) {
        window.Telegram.WebApp.HapticFeedback.impactOccurred("light")
      }
    } catch (error) {
      console.error("Error toggling watchlist:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Button
      variant={inWatchlist ? "default" : "outline"}
      size="icon"
      onClick={toggleWatchlist}
      disabled={loading || checking}
      className={className}
    >
      {loading || checking ? (
        <Loader2 className="w-4 h-4 animate-spin" />
      ) : (
        <Heart className="w-4 h-4" fill={inWatchlist ? "currentColor" : "none"} />
      )}
    </Button>
  )
}
