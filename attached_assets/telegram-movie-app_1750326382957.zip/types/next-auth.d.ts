import "next-auth"
import "next-auth/jwt"

declare module "next-auth" {
  interface Session {
    user: {
      id: string
      name?: string | null
      email?: string | null
      image?: string | null
      telegramId?: string
      username?: string
      firstName?: string
      lastName?: string
    }
  }

  interface User {
    telegramId?: string
    username?: string
    firstName?: string
    lastName?: string
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    telegramId?: string
    username?: string
    firstName?: string
    lastName?: string
  }
}
