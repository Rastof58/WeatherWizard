import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

// In-memory storage for demo - replace with database in production
const watchlistStorage = new Map<string, Set<number>>()

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = session.user.id
    const userWatchlist = watchlistStorage.get(userId) || new Set()

    // Convert to array of movie IDs for now
    // In production, you'd fetch full movie details from database
    const watchlistItems = Array.from(userWatchlist).map((movieId) => ({
      id: `${userId}_${movieId}`,
      movieId,
      userId,
      addedAt: new Date().toISOString(),
    }))

    return NextResponse.json(watchlistItems)
  } catch (error) {
    console.error("Watchlist GET error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { movieId, action } = await request.json()
    const userId = session.user.id

    if (!watchlistStorage.has(userId)) {
      watchlistStorage.set(userId, new Set())
    }

    const userWatchlist = watchlistStorage.get(userId)!

    if (action === "add") {
      userWatchlist.add(movieId)
    } else if (action === "remove") {
      userWatchlist.delete(movieId)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Watchlist POST error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
