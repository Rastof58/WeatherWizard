import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

// Use the same in-memory storage
const watchlistStorage = new Map<string, Set<number>>()

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ inWatchlist: false })
    }

    const { searchParams } = new URL(request.url)
    const movieId = Number.parseInt(searchParams.get("movieId") || "0")
    const userId = session.user.id

    const userWatchlist = watchlistStorage.get(userId) || new Set()
    const inWatchlist = userWatchlist.has(movieId)

    return NextResponse.json({ inWatchlist })
  } catch (error) {
    console.error("Watchlist check error:", error)
    return NextResponse.json({ inWatchlist: false, error: "Error checking watchlist" })
  }
}
