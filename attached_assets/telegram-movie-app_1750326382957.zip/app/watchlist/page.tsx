"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Play, Star, Calendar, Clock, Loader2 } from "lucide-react"
import { MovieAPI, type Movie, getImageUrl } from "@/lib/api"
import { TelegramAuth } from "@/components/telegram-auth"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"

// Simple in-memory watchlist storage
const watchlistStorage = new Map<string, Set<number>>()

export default function WatchlistPage() {
  const { user, isLoading: authLoading } = useAuth()
  const router = useRouter()
  const [watchlistMovies, setWatchlistMovies] = useState<Movie[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchWatchlist = async () => {
      if (!user?.id) {
        setLoading(false)
        return
      }

      try {
        const userWatchlist = watchlistStorage.get(user.id) || new Set()
        const movieIds = Array.from(userWatchlist)

        // Fetch full movie details for each watchlist item
        const moviePromises = movieIds.map((id) => MovieAPI.fetchMovieDetails(id))
        const movies = await Promise.all(moviePromises)
        setWatchlistMovies(movies.filter(Boolean) as Movie[])
      } catch (error) {
        console.error("Error fetching watchlist:", error)
      } finally {
        setLoading(false)
      }
    }

    if (!authLoading) {
      fetchWatchlist()
    }
  }, [user?.id, authLoading])

  if (authLoading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-black text-white">
        <div className="sticky top-0 z-50 bg-black/95 backdrop-blur-sm p-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()} className="text-white">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">My Watchlist</h1>
        </div>

        <div className="p-4">
          <TelegramAuth />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-black/95 backdrop-blur-sm p-4 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="text-white">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg font-semibold">My Watchlist</h1>
        <Badge variant="secondary" className="ml-auto">
          {watchlistMovies.length}
        </Badge>
      </div>

      {/* Content */}
      <div className="p-4">
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-800 aspect-[3/4] rounded-lg mb-2"></div>
                <div className="bg-gray-800 h-4 rounded mb-1"></div>
                <div className="bg-gray-800 h-3 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        ) : watchlistMovies.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {watchlistMovies.map((movie) => (
              <Link key={movie.id} href={`/movie/${movie.id}`}>
                <Card className="bg-gray-900 border-gray-800 hover:bg-gray-800 transition-colors cursor-pointer group">
                  <CardContent className="p-0">
                    <div className="relative">
                      <img
                        src={getImageUrl(movie.poster_path) || "/placeholder.svg?height=400&width=300"}
                        alt={movie.title}
                        className="w-full aspect-[3/4] object-cover rounded-t-lg"
                      />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-t-lg">
                        <Play className="w-12 h-12 text-white" fill="white" />
                      </div>
                      <Badge className="absolute top-2 right-2 bg-yellow-600">
                        <Star className="w-3 h-3 mr-1" fill="white" />
                        {movie.vote_average.toFixed(1)}
                      </Badge>
                    </div>
                    <div className="p-3">
                      <h3 className="font-semibold text-sm line-clamp-2 mb-1">{movie.title}</h3>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <Calendar className="w-3 h-3" />
                        {new Date(movie.release_date).getFullYear()}
                        {movie.runtime && (
                          <>
                            <Clock className="w-3 h-3 ml-1" />
                            {movie.runtime}m
                          </>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-400 mb-4">Your watchlist is empty</p>
            <Button onClick={() => router.push("/")} variant="outline">
              Discover Movies
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
