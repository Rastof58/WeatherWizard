"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Play, Star, Calendar, Clock, Download, Share, Loader2, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { MovieAPI, type Movie, getImageUrl } from "@/lib/api"
import { WatchlistButton } from "@/components/watchlist-button"
import type { MultiSourceResponse } from "@/lib/api"
import { MovieTrailer } from "@/components/movie-trailer"
import { MovieRating } from "@/components/movie-rating"
import { PerformanceTracker } from "@/lib/analytics"
import { useAuth } from "@/lib/auth-context"

export default function MoviePage() {
  const params = useParams()
  const router = useRouter()
  const [movie, setMovie] = useState<Movie | null>(null)
  const [streamingSources, setStreamingSources] = useState<MultiSourceResponse | null>(null)
  const [recommendations, setRecommendations] = useState<Movie[]>([])
  const [loading, setLoading] = useState(true)
  const [streamingLoading, setStreamingLoading] = useState(false)
  const [showPlayer, setShowPlayer] = useState(false)
  const [selectedQuality, setSelectedQuality] = useState<string>("1080p")
  const [error, setError] = useState<string | null>(null)
  const [selectedSource, setSelectedSource] = useState<string>("vidsrc")
  const { user } = useAuth()

  const movieId = Number.parseInt(params.id as string)

  useEffect(() => {
    const fetchMovieData = async () => {
      try {
        setLoading(true)
        setError(null)

        // Fetch movie details
        const movieData = await MovieAPI.fetchMovieDetails(movieId)
        if (!movieData) {
          setError("Movie not found")
          return
        }
        setMovie(movieData)

        // Fetch streaming sources with IMDB ID
        setStreamingLoading(true)
        const streamingData = await MovieAPI.fetchStreamingSources(movieId, movieData.imdb_id)
        setStreamingSources(streamingData)

        // Fetch recommendations
        const recommendationsData = await MovieAPI.fetchRecommendations(movieId)
        setRecommendations(recommendationsData.results.slice(0, 6))
      } catch (err) {
        setError("Failed to load movie data")
        console.error("Error fetching movie data:", err)
      } finally {
        setLoading(false)
        setStreamingLoading(false)
      }
    }

    if (movieId) {
      fetchMovieData()
    }
  }, [movieId])

  // Add this useEffect after the existing useEffect
  useEffect(() => {
    if (movie) {
      PerformanceTracker.trackMovieView(movie.id, movie.title)
    }
  }, [movie])

  const handleShare = () => {
    if (typeof window !== "undefined" && window.Telegram?.WebApp) {
      const tg = window.Telegram.WebApp
      const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(`Check out ${movie?.title}!`)}`
      tg.openLink(shareUrl)
    }
  }

  // Update the handlePlayMovie function to include analytics
  const handlePlayMovie = () => {
    if (streamingSources?.sources?.length) {
      const currentSource = streamingSources.sources.find((s) => s.server === selectedSource)
      PerformanceTracker.trackMoviePlay(movieId, currentSource?.name || "unknown")
      setShowPlayer(true)
    }
  }

  const getCurrentStreamUrl = () => {
    if (!streamingSources?.sources?.length) return ""

    const selectedSourceObj = streamingSources.sources.find((s) => s.server === selectedSource)
    return selectedSourceObj?.url || streamingSources.sources[0].url
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p>Loading movie...</p>
        </div>
      </div>
    )
  }

  if (error || !movie) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-xl mb-4">{error || "Movie not found"}</p>
          <Button onClick={() => router.back()} variant="outline">
            Go Back
          </Button>
        </div>
      </div>
    )
  }

  if (showPlayer) {
    const streamUrl = getCurrentStreamUrl()

    return (
      <div className="min-h-screen bg-black">
        <div className="sticky top-0 z-50 bg-black/95 backdrop-blur-sm p-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setShowPlayer(false)} className="text-white">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-lg font-semibold truncate">{movie.title}</h1>
            {streamingSources?.sources && streamingSources.sources.length > 1 && (
              <div className="flex gap-2 mt-2 flex-wrap">
                {streamingSources.sources.map((source) => (
                  <Button
                    key={source.server}
                    size="sm"
                    variant={selectedSource === source.server ? "default" : "outline"}
                    onClick={() => setSelectedSource(source.server)}
                    className="text-xs"
                  >
                    {source.name}
                  </Button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="aspect-video">
          {streamUrl ? (
            <iframe
              src={streamUrl}
              className="w-full h-full"
              allowFullScreen
              allow="autoplay; encrypted-media"
              title={`${movie.title} - ${selectedQuality}`}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-900">
              <div className="text-center">
                <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                <p>Streaming source not available</p>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-black/95 backdrop-blur-sm p-4 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="text-white">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg font-semibold truncate">{movie.title}</h1>
      </div>

      {/* Backdrop */}
      <div className="relative">
        <img
          src={getImageUrl(movie.backdrop_path, "w1280") || "/placeholder.svg?height=400&width=800"}
          alt={movie.title}
          className="w-full h-64 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
        <Button
          onClick={handlePlayMovie}
          disabled={streamingLoading || !streamingSources?.sources?.length}
          className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full disabled:opacity-50"
        >
          {streamingLoading ? (
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
          ) : (
            <Play className="w-5 h-5 mr-2" fill="white" />
          )}
          {streamingLoading ? "Loading..." : "Watch Now"}
        </Button>
      </div>

      {/* Content */}
      <div className="p-4 space-y-6">
        {/* Movie Info */}
        <div className="flex gap-4">
          <img
            src={getImageUrl(movie.poster_path, "w300") || "/placeholder.svg?height=400&width=300"}
            alt={movie.title}
            className="w-24 h-36 object-cover rounded-lg flex-shrink-0"
          />
          <div className="flex-1 space-y-2">
            <h2 className="text-xl font-bold">{movie.title}</h2>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500" fill="currentColor" />
                {movie.vote_average.toFixed(1)}
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {new Date(movie.release_date).getFullYear()}
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {movie.runtime}m
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {movie.genres.map((genre) => (
                <Badge key={genre.id} variant="secondary" className="text-xs">
                  {genre.name}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            onClick={handlePlayMovie}
            disabled={streamingLoading || !streamingSources?.sources?.length}
            className="flex-1 bg-red-600 hover:bg-red-700 disabled:opacity-50"
          >
            {streamingLoading ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Play className="w-4 h-4 mr-2" fill="white" />
            )}
            Play
          </Button>
          <WatchlistButton movieId={movie.id} />
          <Button variant="outline" size="icon" onClick={handleShare}>
            <Share className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="icon">
            <Download className="w-4 h-4" />
          </Button>
        </div>

        {/* Streaming Quality Options */}
        {streamingSources?.sources && streamingSources.sources.length > 1 && (
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3">Streaming Sources</h3>
              <div className="grid grid-cols-2 gap-2">
                {streamingSources.sources.map((source) => (
                  <Button
                    key={source.server}
                    size="sm"
                    variant={selectedSource === source.server ? "default" : "outline"}
                    onClick={() => setSelectedSource(source.server)}
                    className="text-xs"
                  >
                    {source.name} ({source.quality})
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Overview */}
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-2">Overview</h3>
            <p className="text-gray-300 text-sm leading-relaxed">{movie.overview}</p>
          </CardContent>
        </Card>

        {/* Movie Rating */}
        <MovieRating movieId={movie.id} movieTitle={movie.title} />

        {/* Movie Trailers */}
        <MovieTrailer movieId={movie.id} movieTitle={movie.title} />

        {/* Recommendations */}
        {recommendations.length > 0 && (
          <div>
            <h3 className="font-semibold mb-4">You might also like</h3>
            <div className="grid grid-cols-3 gap-3">
              {recommendations.map((rec) => (
                <div key={rec.id} onClick={() => router.push(`/movie/${rec.id}`)} className="cursor-pointer group">
                  <img
                    src={getImageUrl(rec.poster_path, "w300") || "/placeholder.svg?height=200&width=150"}
                    alt={rec.title}
                    className="w-full aspect-[3/4] object-cover rounded-lg group-hover:opacity-80 transition-opacity"
                  />
                  <p className="text-xs mt-2 line-clamp-2">{rec.title}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
