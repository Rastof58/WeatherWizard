"use client"

import { TelegramAuth } from "@/components/telegram-auth"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

export default function SignInPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="mb-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="text-white">
          <ArrowLeft className="w-5 h-5" />
        </Button>
      </div>

      <div className="flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">🎬 CineStream</h1>
            <p className="text-gray-400">Sign in to access your watchlist and personalized recommendations</p>
          </div>

          <TelegramAuth />

          <div className="mt-6 text-center text-sm text-gray-500">
            <p>This app uses Telegram for authentication.</p>
            <p>No password is required.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
