"use client"

import { useState, useEffect } from "react"
import { Search, Play, Star, Calendar, Clock, Loader2, Heart } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { MovieAPI, type Movie, getImageUrl } from "@/lib/api"
import { WatchlistButton } from "@/components/watchlist-button"
import { useRouter } from "next/navigation"
import { GenreFilter } from "@/components/genre-filter"
import { OfflineIndicator } from "@/components/offline-indicator"
import { useAuth } from "@/lib/auth-context"

export default function HomePage() {
  const [movies, setMovies] = useState<Movie[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(true)
  const [searching, setSearching] = useState(false)
  const [category, setCategory] = useState("popular")
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const [selectedGenre, setSelectedGenre] = useState<number | null>(null)
  const { user } = useAuth()

  const categories = [
    { id: "popular", label: "Popular" },
    { id: "trending", label: "Trending" },
    { id: "top_rated", label: "Top Rated" },
    { id: "upcoming", label: "Upcoming" },
  ]

  // Fetch movies by category
  const fetchMoviesByCategory = async (selectedCategory: string) => {
    try {
      setLoading(true)
      setError(null)
      const response = await MovieAPI.fetchMovies(selectedCategory)
      setMovies(response.results)
    } catch (err) {
      setError("Failed to fetch movies. Please try again.")
      console.error("Error fetching movies:", err)
    } finally {
      setLoading(false)
    }
  }

  const fetchMoviesByGenre = async (genreId: number | null) => {
    try {
      setLoading(true)
      setError(null)
      const response = genreId ? await MovieAPI.discoverMovies(genreId) : await MovieAPI.fetchMovies(category)
      setMovies(response.results)
    } catch (err) {
      setError("Failed to fetch movies. Please try again.")
      console.error("Error fetching movies:", err)
    } finally {
      setLoading(false)
    }
  }

  // Search movies
  const searchMovies = async (query: string) => {
    if (!query.trim()) {
      fetchMoviesByCategory(category)
      return
    }

    try {
      setSearching(true)
      setError(null)
      const response = await MovieAPI.searchMovies(query)
      setMovies(response.results)
    } catch (err) {
      setError("Search failed. Please try again.")
      console.error("Error searching movies:", err)
    } finally {
      setSearching(false)
    }
  }

  // Initialize Telegram Mini App and fetch initial data
  useEffect(() => {
    if (typeof window !== "undefined" && window.Telegram?.WebApp) {
      const tg = window.Telegram.WebApp
      tg.ready()
      tg.expand()
      tg.setHeaderColor("#000000")
    }

    fetchMoviesByCategory("popular")
  }, [])

  // Handle category change
  useEffect(() => {
    if (!searchQuery) {
      if (selectedGenre) {
        fetchMoviesByGenre(selectedGenre)
      } else {
        fetchMoviesByCategory(category)
      }
    }
  }, [category, selectedGenre])

  // Handle search with debounce
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      searchMovies(searchQuery)
    }, 500)

    return () => clearTimeout(timeoutId)
  }, [searchQuery])

  return (
    <div className="min-h-screen bg-black text-white">
      <OfflineIndicator />
      {/* Header */}
      <div className="sticky top-0 z-50 bg-black/95 backdrop-blur-sm border-b border-gray-800">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">🎬 CineStream</h1>
            {user && (
              <Button variant="ghost" size="icon" onClick={() => router.push("/watchlist")} className="text-white">
                <Heart className="w-5 h-5" />
              </Button>
            )}
          </div>

          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search movies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-gray-900 border-gray-700 text-white placeholder-gray-400"
            />
            {searching && (
              <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 animate-spin" />
            )}
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={category === cat.id ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  setCategory(cat.id)
                  setSelectedGenre(null) // Clear genre filter when changing category
                }}
                className="whitespace-nowrap"
                disabled={loading || searching}
              >
                {cat.label}
              </Button>
            ))}
            <GenreFilter
              onGenreSelect={(genreId) => {
                setSelectedGenre(genreId)
                if (genreId) {
                  fetchMoviesByGenre(genreId)
                }
              }}
              selectedGenre={selectedGenre}
            />
          </div>
        </div>
      </div>

      {user && (
        <div className="px-4 pb-2">
          <p className="text-sm text-gray-400">Welcome back, {user.first_name}! 👋</p>
        </div>
      )}

      {/* Content */}
      <div className="p-4">
        {error && (
          <div className="bg-red-900/50 border border-red-700 rounded-lg p-4 mb-4 text-center">
            <p className="text-red-200">{error}</p>
            <Button variant="outline" size="sm" className="mt-2" onClick={() => fetchMoviesByCategory(category)}>
              Retry
            </Button>
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-gray-800 aspect-[3/4] rounded-lg mb-2"></div>
                <div className="bg-gray-800 h-4 rounded mb-1"></div>
                <div className="bg-gray-800 h-3 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        ) : movies.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {movies.map((movie) => (
              <Link key={movie.id} href={`/movie/${movie.id}`}>
                <Card className="bg-gray-900 border-gray-800 hover:bg-gray-800 transition-colors cursor-pointer group">
                  <CardContent className="p-0">
                    <div className="relative">
                      <img
                        src={getImageUrl(movie.poster_path) || "/placeholder.svg?height=400&width=300"}
                        alt={movie.title}
                        className="w-full aspect-[3/4] object-cover rounded-t-lg"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement
                          target.src = "/placeholder.svg?height=400&width=300"
                        }}
                      />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-t-lg">
                        <Play className="w-12 h-12 text-white" fill="white" />
                      </div>
                      <Badge className="absolute top-2 right-2 bg-yellow-600">
                        <Star className="w-3 h-3 mr-1" fill="white" />
                        {movie.vote_average.toFixed(1)}
                      </Badge>
                    </div>
                    <div className="p-3">
                      <div className="flex items-start justify-between mb-1">
                        <h3 className="font-semibold text-sm line-clamp-2 flex-1 mr-2">{movie.title}</h3>
                        <WatchlistButton movieId={movie.id} className="flex-shrink-0" />
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-400">
                        <Calendar className="w-3 h-3" />
                        {new Date(movie.release_date).getFullYear()}
                        {movie.runtime && (
                          <>
                            <Clock className="w-3 h-3 ml-1" />
                            {movie.runtime}m
                          </>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-400">
              {searchQuery ? `No movies found for "${searchQuery}"` : "No movies available"}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
