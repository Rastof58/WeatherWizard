// Enhanced API service with real TMDB integration and multiple streaming sources
export interface Movie {
  id: number
  title: string
  poster_path: string
  backdrop_path: string
  release_date: string
  vote_average: number
  overview: string
  runtime: number
  genres: { id: number; name: string }[]
  imdb_id?: string
  original_language: string
  popularity: number
  adult: boolean
}

export interface MovieResponse {
  page: number
  results: Movie[]
  total_pages: number
  total_results: number
}

export interface StreamingSource {
  name: string
  quality: string
  url: string
  type: string
  server: string
}

export interface MultiSourceResponse {
  success: boolean
  sources: StreamingSource[]
  subtitles?: Array<{
    file: string
    label: string
    kind: string
  }>
}

export interface WatchlistItem {
  id: string
  movieId: number
  userId: string
  addedAt: string
  movie: Movie
}

// Cache interface for offline support
interface CacheItem<T> {
  data: T
  timestamp: number
  expiry: number
}

class CacheManager {
  private static CACHE_PREFIX = "cinestream_"
  private static DEFAULT_EXPIRY = 1000 * 60 * 30 // 30 minutes

  static set<T>(key: string, data: T, expiry = this.DEFAULT_EXPIRY): void {
    if (typeof window === "undefined") return

    const cacheItem: CacheItem<T> = {
      data,
      timestamp: Date.now(),
      expiry: Date.now() + expiry,
    }

    try {
      localStorage.setItem(this.CACHE_PREFIX + key, JSON.stringify(cacheItem))
    } catch (error) {
      console.warn("Cache storage failed:", error)
    }
  }

  static get<T>(key: string): T | null {
    if (typeof window === "undefined") return null

    try {
      const cached = localStorage.getItem(this.CACHE_PREFIX + key)
      if (!cached) return null

      const cacheItem: CacheItem<T> = JSON.parse(cached)

      if (Date.now() > cacheItem.expiry) {
        this.remove(key)
        return null
      }

      return cacheItem.data
    } catch (error) {
      console.warn("Cache retrieval failed:", error)
      return null
    }
  }

  static remove(key: string): void {
    if (typeof window === "undefined") return
    localStorage.removeItem(this.CACHE_PREFIX + key)
  }

  static clear(): void {
    if (typeof window === "undefined") return

    const keys = Object.keys(localStorage).filter((key) => key.startsWith(this.CACHE_PREFIX))
    keys.forEach((key) => localStorage.removeItem(key))
  }
}

export class MovieAPI {
  private static baseURL = "https://api.themoviedb.org/3"
  private static apiKey = process.env.NEXT_PUBLIC_TMDB_API_KEY

  private static async fetchWithCache<T>(endpoint: string, cacheKey: string, expiry?: number): Promise<T> {
    // Try cache first
    const cached = CacheManager.get<T>(cacheKey)
    if (cached) return cached

    // Construct URL with proper API key handling
    const separator = endpoint.includes("?") ? "&" : "?"
    const url = `${this.baseURL}${endpoint}${separator}api_key=${this.apiKey}`

    // Fetch from API
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`API request failed: ${response.statusText}`)
    }

    const data = await response.json()

    // Cache the result
    CacheManager.set(cacheKey, data, expiry)

    return data
  }

  // Fetch movies by category with caching
  static async fetchMovies(category = "popular", page = 1): Promise<MovieResponse> {
    const endpoint = `/${category === "trending" ? "trending/movie/week" : `movie/${category}`}?page=${page}`
    const cacheKey = `movies_${category}_${page}`

    return this.fetchWithCache<MovieResponse>(endpoint, cacheKey)
  }

  // Search movies with caching
  static async searchMovies(query: string, page = 1): Promise<MovieResponse> {
    if (!query.trim()) {
      return { page: 1, results: [], total_pages: 0, total_results: 0 }
    }

    const endpoint = `/search/movie?query=${encodeURIComponent(query)}&page=${page}`
    const cacheKey = `search_${query}_${page}`

    return this.fetchWithCache<MovieResponse>(endpoint, cacheKey, 1000 * 60 * 10) // 10 min cache for searches
  }

  // Fetch single movie details with caching
  static async fetchMovieDetails(movieId: number): Promise<Movie | null> {
    try {
      const endpoint = `/movie/${movieId}?append_to_response=credits,videos`
      const cacheKey = `movie_${movieId}`

      return await this.fetchWithCache<Movie>(endpoint, cacheKey)
    } catch (error) {
      console.error("Error fetching movie details:", error)
      return null
    }
  }

  // Fetch multiple streaming sources
  static async fetchStreamingSources(movieId: number, imdbId?: string): Promise<MultiSourceResponse> {
    const sources: StreamingSource[] = []

    try {
      // Vidsrc.to
      sources.push({
        name: "Vidsrc",
        quality: "1080p",
        url: `https://vidsrc.to/embed/movie/${movieId}`,
        type: "iframe",
        server: "vidsrc",
      })

      // Vidsrc.me (alternative)
      if (imdbId) {
        sources.push({
          name: "Vidsrc Pro",
          quality: "1080p",
          url: `https://vidsrc.me/embed/movie?imdb=${imdbId}`,
          type: "iframe",
          server: "vidsrc_pro",
        })
      }

      // 2embed
      sources.push({
        name: "2Embed",
        quality: "720p",
        url: `https://www.2embed.to/embed/tmdb/movie?id=${movieId}`,
        type: "iframe",
        server: "2embed",
      })

      // SuperEmbed
      sources.push({
        name: "SuperEmbed",
        quality: "1080p",
        url: `https://multiembed.mov/directstream.php?video_id=${movieId}&tmdb=1`,
        type: "iframe",
        server: "superembed",
      })

      return {
        success: true,
        sources: sources.filter((s) => s.url), // Filter out any invalid sources
      }
    } catch (error) {
      console.error("Error fetching streaming sources:", error)
      return {
        success: false,
        sources: [
          {
            name: "Vidsrc",
            quality: "1080p",
            url: `https://vidsrc.to/embed/movie/${movieId}`,
            type: "iframe",
            server: "vidsrc",
          },
        ],
      }
    }
  }

  // Get movie recommendations with caching
  static async fetchRecommendations(movieId: number): Promise<MovieResponse> {
    const endpoint = `/movie/${movieId}/recommendations?`
    const cacheKey = `recommendations_${movieId}`

    try {
      return await this.fetchWithCache<MovieResponse>(endpoint, cacheKey)
    } catch (error) {
      console.error("Error fetching recommendations:", error)
      return { page: 1, results: [], total_pages: 0, total_results: 0 }
    }
  }

  // Get trending movies
  static async fetchTrending(timeWindow: "day" | "week" = "week"): Promise<MovieResponse> {
    const endpoint = `/trending/movie/${timeWindow}?`
    const cacheKey = `trending_${timeWindow}`

    return this.fetchWithCache<MovieResponse>(endpoint, cacheKey)
  }

  // Get movie genres
  static async fetchGenres(): Promise<{ genres: Array<{ id: number; name: string }> }> {
    const endpoint = `/genre/movie/list?`
    const cacheKey = "movie_genres"

    return this.fetchWithCache(endpoint, cacheKey, 1000 * 60 * 60 * 24) // Cache for 24 hours
  }

  // Discover movies by genre
  static async discoverMovies(genreId?: number, page = 1): Promise<MovieResponse> {
    const genreParam = genreId ? `&with_genres=${genreId}` : ""
    const endpoint = `/discover/movie?sort_by=popularity.desc${genreParam}&page=${page}`
    const cacheKey = `discover_${genreId || "all"}_${page}`

    return this.fetchWithCache<MovieResponse>(endpoint, cacheKey)
  }
}

// Utility functions
export const getImageUrl = (path: string, size: "w300" | "w500" | "w780" | "w1280" | "original" = "w500") => {
  if (!path) return "/placeholder.svg?height=400&width=300"
  if (path.startsWith("http")) return path
  return `https://image.tmdb.org/t/p/${size}${path}`
}

export const getStreamingUrl = (source: StreamingSource) => {
  return source.url
}

// Watchlist API functions
export class WatchlistAPI {
  static async addToWatchlist(movieId: number, userId: string): Promise<boolean> {
    try {
      const response = await fetch("/api/watchlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ movieId, userId, action: "add" }),
      })
      return response.ok
    } catch (error) {
      console.error("Error adding to watchlist:", error)
      return false
    }
  }

  static async removeFromWatchlist(movieId: number, userId: string): Promise<boolean> {
    try {
      const response = await fetch("/api/watchlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ movieId, userId, action: "remove" }),
      })
      return response.ok
    } catch (error) {
      console.error("Error removing from watchlist:", error)
      return false
    }
  }

  static async getWatchlist(userId: string): Promise<WatchlistItem[]> {
    try {
      const response = await fetch(`/api/watchlist?userId=${userId}`)
      if (!response.ok) return []
      return await response.json()
    } catch (error) {
      console.error("Error fetching watchlist:", error)
      return []
    }
  }

  static async isInWatchlist(movieId: number, userId: string): Promise<boolean> {
    try {
      const response = await fetch(`/api/watchlist/check?movieId=${movieId}&userId=${userId}`)
      if (!response.ok) return false
      const data = await response.json()
      return data.inWatchlist
    } catch (error) {
      console.error("Error checking watchlist:", error)
      return false
    }
  }
}

export { CacheManager }
