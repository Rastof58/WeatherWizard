"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface TelegramUser {
  id: string
  first_name: string
  last_name?: string
  username?: string
  photo_url?: string
  auth_date?: number
}

interface AuthContextType {
  user: TelegramUser | null
  isLoading: boolean
  login: () => void
  logout: () => void
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  login: () => {},
  logout: () => {},
})

export const useAuth = () => useContext(AuthContext)

interface AuthProviderProps {
  children: ReactNode
}

const USER_STORAGE_KEY = "cinestream_user"

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<TelegramUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Initialize auth state from localStorage and Telegram WebApp
  useEffect(() => {
    const initAuth = () => {
      try {
        // Try to get user from localStorage first
        const storedUser = localStorage.getItem(USER_STORAGE_KEY)
        if (storedUser) {
          setUser(JSON.parse(storedUser))
        }

        // Check if we're in Telegram WebApp
        if (typeof window !== "undefined" && window.Telegram?.WebApp) {
          const tg = window.Telegram.WebApp
          tg.ready()

          // If Telegram provides user data, use it
          if (tg.initDataUnsafe?.user) {
            const telegramUser = tg.initDataUnsafe.user
            const userData: TelegramUser = {
              id: telegramUser.id.toString(),
              first_name: telegramUser.first_name,
              last_name: telegramUser.last_name,
              username: telegramUser.username,
              photo_url: telegramUser.photo_url,
              auth_date: Date.now(),
            }

            setUser(userData)
            localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(userData))
          }
        }
      } catch (error) {
        console.error("Auth initialization error:", error)
      } finally {
        setIsLoading(false)
      }
    }

    initAuth()
  }, [])

  const login = () => {
    if (typeof window !== "undefined" && window.Telegram?.WebApp?.initDataUnsafe?.user) {
      const telegramUser = window.Telegram.WebApp.initDataUnsafe.user
      const userData: TelegramUser = {
        id: telegramUser.id.toString(),
        first_name: telegramUser.first_name,
        last_name: telegramUser.last_name,
        username: telegramUser.username,
        photo_url: telegramUser.photo_url,
        auth_date: Date.now(),
      }

      setUser(userData)
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(userData))
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem(USER_STORAGE_KEY)
  }

  return <AuthContext.Provider value={{ user, isLoading, login, logout }}>{children}</AuthContext.Provider>
}
