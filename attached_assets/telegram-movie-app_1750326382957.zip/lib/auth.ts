import type { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"

export interface TelegramUser {
  id: string
  first_name: string
  last_name?: string
  username?: string
  photo_url?: string
  auth_date: number
  hash: string
}

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      id: "telegram",
      name: "Telegram",
      credentials: {
        telegramData: { label: "Telegram Data", type: "text" },
      },
      async authorize(credentials) {
        try {
          // For Telegram Mini Apps, we'll use a simpler approach
          // that doesn't require server-side validation
          if (!credentials?.telegramData) {
            return null
          }

          let telegramUser
          try {
            telegramUser = JSON.parse(credentials.telegramData)
          } catch (e) {
            console.error("Failed to parse Telegram data:", e)
            return null
          }

          if (!telegramUser || !telegramUser.id) {
            return null
          }

          return {
            id: telegramUser.id.toString(),
            name: `${telegramUser.first_name || ""} ${telegramUser.last_name || ""}`.trim(),
            email: telegramUser.username ? `${telegramUser.username}@telegram.user` : undefined,
            image: telegramUser.photo_url,
            telegramId: telegramUser.id.toString(),
            username: telegramUser.username,
            firstName: telegramUser.first_name,
            lastName: telegramUser.last_name,
          }
        } catch (error) {
          console.error("Telegram auth error:", error)
          return null
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.telegramId = user.telegramId
        token.username = user.username
        token.firstName = user.firstName
        token.lastName = user.lastName
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.sub!
        session.user.telegramId = token.telegramId as string
        session.user.username = (token.username as string) || ""
        session.user.firstName = (token.firstName as string) || ""
        session.user.lastName = (token.lastName as string) || ""
      }
      return session
    },
  },
  pages: {
    signIn: "/auth/signin",
  },
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  debug: process.env.NODE_ENV === "development",
}
