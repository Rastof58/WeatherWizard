// Analytics and performance tracking for the Telegram Mini App

interface AnalyticsEvent {
  event: string
  properties: Record<string, any>
  timestamp: number
  userId?: string
}

class Analytics {
  private static events: AnalyticsEvent[] = []
  private static userId: string | null = null

  static setUserId(userId: string) {
    this.userId = userId
  }

  static track(event: string, properties: Record<string, any> = {}) {
    const analyticsEvent: AnalyticsEvent = {
      event,
      properties,
      timestamp: Date.now(),
      userId: this.userId || undefined,
    }

    this.events.push(analyticsEvent)

    // In production, send to analytics service
    if (process.env.NODE_ENV === "development") {
      console.log("Analytics Event:", analyticsEvent)
    }

    // Send to Telegram if available
    if (typeof window !== "undefined" && window.Telegram?.WebApp) {
      try {
        window.Telegram.WebApp.sendData(
          JSON.stringify({
            type: "analytics",
            event: analyticsEvent,
          }),
        )
      } catch (error) {
        // Silently fail if Telegram is not available
      }
    }
  }

  static getEvents() {
    return this.events
  }

  static clearEvents() {
    this.events = []
  }
}

// Performance tracking
export class PerformanceTracker {
  private static marks: Map<string, number> = new Map()

  static startTiming(label: string) {
    this.marks.set(label, performance.now())
  }

  static endTiming(label: string) {
    const startTime = this.marks.get(label)
    if (startTime) {
      const duration = performance.now() - startTime
      Analytics.track("performance_timing", {
        label,
        duration,
      })
      this.marks.delete(label)
      return duration
    }
    return 0
  }

  static trackPageLoad(pageName: string) {
    Analytics.track("page_view", {
      page: pageName,
      timestamp: Date.now(),
    })
  }

  static trackMovieView(movieId: number, movieTitle: string) {
    Analytics.track("movie_view", {
      movieId,
      movieTitle,
    })
  }

  static trackMoviePlay(movieId: number, source: string) {
    Analytics.track("movie_play", {
      movieId,
      source,
    })
  }

  static trackSearch(query: string, resultsCount: number) {
    Analytics.track("search", {
      query,
      resultsCount,
    })
  }

  static trackWatchlistAction(action: "add" | "remove", movieId: number) {
    Analytics.track("watchlist_action", {
      action,
      movieId,
    })
  }
}

export default Analytics
